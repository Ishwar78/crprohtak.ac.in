// Computer.jsx - Departments > Computer Engineering (route: /departments/computer).
// Page order: hero -> department switcher -> search + About / Staff tabs -> department highlights.
// Own styles (Computer.css, every class starts with "cse-"). Nothing here is shared with another department.
//
// HOW THE DEPARTMENT UPDATES THIS PAGE - everything is a list at the top of this file:
//   hero         banner picture, title, short introduction and quick facts
//   collage      the three About pictures: [small left, small right, large below]
//   about        the About sections (heading, paragraphs, bullet items)
//   staff        one object per person: name, role, photo, and OPTIONAL qualification / experience / about
//                (empty fields are simply not shown - add them whenever they are available)
//   highlights   the four visual cards at the bottom
// All pictures live in public/images/departments/computer/ - nothing is loaded from the old website.
// A missing picture shows a clean placeholder, a missing staff photo shows the person's initials.
//
// FILES TO COPY from the old website (old path -> new path):
//   /media/Departments/COMPUTER2_MlmNDN2.jpg  -> public/images/departments/computer/hero.jpg
//   /media/teachers/<name>.jpeg               -> public/images/departments/computer/staff/<name>.jpeg   (9 photos, names used below)
//   about-1.jpg, about-2.jpg, about-3.jpg     -> three department pictures for the About collage
//   highlight-labs.jpg, highlight-since.jpg, highlight-results.jpg, highlight-placements.jpg -> backgrounds of the highlight cards
import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  FiChevronRight, FiChevronDown, FiSearch, FiX, FiImage, FiInfo, FiLayers, FiBriefcase, FiMonitor, FiAward,
  FiTrendingUp, FiCheckCircle, FiFileText, FiUsers, FiClock, FiUser,
} from "react-icons/fi";
import "./Computer.css";

const IMG = "/images/departments/computer";

const hero = {
  image: `${IMG}/hero.jpg`,
  title: "Computer Engineering",
  lead: "Software, hardware, networking, robotics and artificial intelligence - hands-on training for the IT industry.",
  facts: ["Established 1998", "3-year diploma", "54 seats"],
};

// Department switcher: the first five are shown directly, the rest sit under "More +".
const switcher = {
  main: [
    { label: "Civil", to: "/departments/civil" },
    { label: "Computer", to: "/departments/computer" },
    { label: "Electrical", to: "/departments/electrical" },
    { label: "Electronics", to: "/departments/electronics" },
    { label: "Mechanical", to: "/departments/mechanical" },
  ],
  more: [
    { label: "Plastic Technology", to: "/departments/plastic" },
    { label: "Applied Sciences", to: "/departments/applied-science" },
    { label: "Workshop", to: "/departments/workshop" },
  ],
  current: "/departments/computer",
};

// Two small pictures side by side on top, one large picture below.
const collage = [
  { src: `${IMG}/about-1.jpg`, alt: "Computer Engineering department - picture 1" },
  { src: `${IMG}/about-2.jpg`, alt: "Computer Engineering department - picture 2" },
  { src: `${IMG}/about-3.jpg`, alt: "Computer Engineering department - picture 3" },
];

// view: "text" = paragraphs only, "chips" = items shown as chips, "list" = items shown as a tick list.
// paragraphs come before the items, closing paragraphs after them.
const about = [
  {
    id: "intro",
    title: "About the department",
    icon: FiInfo,
    view: "text",
    wide: true,
    paragraphs: [
      "The Department of Computer Engineering, established in the year 1998, has consistently played a vital role in shaping skilled professionals for the IT industry. The department focuses on providing quality education and skill development in the vast and rapidly evolving field of computer engineering, which encompasses the study and application of software, hardware, networking, robotics & artificial intelligence, etc.",
    ],
  },
  {
    id: "overview",
    title: "Department overview",
    icon: FiLayers,
    view: "text",
    paragraphs: [
      "Computer engineering involves the design, development, and testing of computer systems, including both hardware and software. Computer engineers work on a wide range of tasks, from designing microchips and circuit boards to developing software for mobile devices and computer systems. They also work on networks, robotics, and artificial intelligence.",
    ],
  },
  {
    id: "jobs",
    title: "Job prospects",
    icon: FiBriefcase,
    view: "chips",
    paragraphs: [
      "Computer Engineering graduates have a wide range of employment opportunities across public and private sectors. Typical job roles include:",
    ],
    items: [
      "Computer Programmer", "Software Developer", "Data Analyst", "Web Developer", "Data Engineer",
      "Data Scientist", "Application Developer", "System Analyst", "Network Engineer",
    ],
  },
  {
    id: "labs",
    title: "Department laboratories",
    icon: FiMonitor,
    view: "chips",
    wide: true,
    paragraphs: [
      "The department boasts well-equipped laboratories and workshops aimed at strengthening theoretical knowledge with hands-on practical training. Key labs include:",
    ],
    items: [
      "Operating System Lab", "FIT lab", "MultiMedia Application Lab", "Hardware Lab", "Project Lab",
      "Python Lab", "Cloud Computing Lab", "PIC Lab", "CN Lab", "PHP Lab",
    ],
    closing: [
      "These labs are furnished with modern equipment to meet industry standards and curriculum requirements providing hands-on training to students in the modern computer era to equip them with requisite knowledge.",
    ],
  },
  {
    id: "placements",
    title: "Placement status",
    icon: FiAward,
    view: "list",
    paragraphs: [
      "The department has demonstrated commendable placement outcomes in the year 2025. Key placement students are as under:",
    ],
    items: [
      "Ms. Ashmita placed in PISOFT Informatics Pvt. Ltd.",
      "Mr. Deva placed in Reliance Projects Management Pvt. Ltd.",
      "Ms. Tannu placed in VVDN Technology Pvt. Ltd.",
      "Ms. Nisha placed in VVDN Technology Pvt. Ltd.",
      "Ms. Sonia placed in VVDN Technology Pvt. Ltd.",
    ],
  },
  {
    id: "academic",
    title: "Academic performance",
    icon: FiTrendingUp,
    view: "list",
    paragraphs: [
      "The academic performance of students is a key focus area for the department. The academic record of students reflects their achievements:",
    ],
    items: ["75% of students cleared the 5th semester. Top performer: Ms. Ashmita : 98%"],
    closing: [
      "The department continues to strive for improved academic excellence through interactive teaching methodologies and hands-on laboratory exposure. Efforts are continuously made to enhance academic results through remedial classes, workshops, and individual mentoring.",
      "The department remains committed to preparing students for both professional and academic success by offering rigorous training, career guidance, and industrial exposure.",
    ],
  },
];

// One object per person. qualification, experience and about are optional - leave them out until they are available.
// Example of a full entry:  { name: "...", role: "...", photo: "...", qualification: "M.Tech (CSE)", experience: "12 years", about: "One or two lines." }
const staff = [
  { name: "Parveen Kohar", role: "Head of Department", photo: `${IMG}/staff/parveen-kohar.jpeg` },
  { name: "Dr. Ravinder Rathee", role: "Senior Lecturer", photo: `${IMG}/staff/ravinder-rathee.jpeg` },
  { name: "Ms Priyanka", role: "Lecturer", photo: `${IMG}/staff/priyanka.jpeg` },
  { name: "Ajeta Nandal", role: "Lecturer", photo: `${IMG}/staff/ajyeta-nandal.jpeg` },
  { name: "Ms Keerti Kumari", role: "Junior Programmer", photo: `${IMG}/staff/keerti-kumari.jpeg` },
  { name: "Ashok Kumar", role: "Workshop Instructor", photo: `${IMG}/staff/ashok-kumar.jpeg` },
  { name: "Shashi Kumar", role: "Workshop Instructor", photo: `${IMG}/staff/shashi-kumar.jpeg` },
  { name: "Mr Dalvir Singh", role: "Lab Instructor", photo: `${IMG}/staff/dalvir-singh.jpeg` },
  { name: "Poonam Kumari", role: "Lab Instructor", photo: `${IMG}/staff/poonam-kumari.jpeg` },
];

const highlights = [
  {
    icon: FiMonitor, value: "10", label: "Laboratories", image: `${IMG}/highlight-labs.jpg`,
    text: "Operating System, Python, Cloud Computing, Hardware, Project and more - practical training for every subject.",
  },
  {
    icon: FiClock, value: "1998", label: "Established", image: `${IMG}/highlight-since.jpg`,
    text: "Shaping skilled professionals for the IT industry since 1998.",
  },
  {
    icon: FiTrendingUp, value: "75%", label: "Cleared 5th semester", image: `${IMG}/highlight-results.jpg`,
    text: "Top performer Ms. Ashmita scored 98%.",
  },
  {
    icon: FiBriefcase, value: "2025", label: "Placements", image: `${IMG}/highlight-placements.jpg`,
    text: "Students placed at PISOFT Informatics, Reliance Projects Management and VVDN Technology.",
  },
];

// ---------------------------------------------------------------------------------------------

const initials = (name) =>
  name
    .replace(/^(dr|mr|ms|mrs|er)\.?\s+/i, "")
    .split(/\s+/)
    .slice(0, 2)
    .map((word) => word[0])
    .join("")
    .toUpperCase();

// Wraps the searched word in <mark> so it is easy to spot.
function Mark({ text, query }) {
  if (!query) return text;
  const safe = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return text.split(new RegExp(`(${safe})`, "ig")).map((part, i) =>
    part.toLowerCase() === query.toLowerCase() ? <mark key={i}>{part}</mark> : part,
  );
}

// One picture with a placeholder when the file is missing.
function Photo({ src, alt, className = "" }) {
  const [failed, setFailed] = useState(false);
  return (
    <figure className={`cse-photo ${className}`}>
      {failed ? (
        <div className="cse-photo__empty" aria-hidden="true">
          <FiImage />
          <span>Photo coming soon</span>
        </div>
      ) : (
        <img src={src} alt={alt} loading="lazy" decoding="async" onError={() => setFailed(true)} />
      )}
    </figure>
  );
}

function Avatar({ person }) {
  const [failed, setFailed] = useState(false);
  return (
    <div className="cse-avatar">
      {failed || !person.photo ? (
        <span aria-hidden="true">{initials(person.name) || <FiUser />}</span>
      ) : (
        <img src={person.photo} alt={person.name} loading="lazy" decoding="async" onError={() => setFailed(true)} />
      )}
    </div>
  );
}

// Keeps only the parts of a section that contain the searched word (the whole section if its heading matches).
function filterSection(section, q) {
  if (!q) return section;
  const has = (text) => text.toLowerCase().includes(q);
  if (has(section.title)) return section;
  const paragraphs = (section.paragraphs || []).filter(has);
  const items = (section.items || []).filter(has);
  const closing = (section.closing || []).filter(has);
  if (!paragraphs.length && !items.length && !closing.length) return null;
  return { ...section, paragraphs, items, closing };
}

export default function Computer() {
  const [tab, setTab] = useState("about");
  const [query, setQuery] = useState("");
  const [moreOpen, setMoreOpen] = useState(false);
  const moreRef = useRef(null);
  const tabRefs = useRef({});

  const q = query.trim().toLowerCase();

  // "More +" closes on outside click or Esc.
  useEffect(() => {
    if (!moreOpen) return undefined;
    const onClick = (event) => {
      if (moreRef.current && !moreRef.current.contains(event.target)) setMoreOpen(false);
    };
    const onKey = (event) => {
      if (event.key === "Escape") setMoreOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onClick);
      document.removeEventListener("keydown", onKey);
    };
  }, [moreOpen]);

  const pickTab = (id, focus = false) => {
    setTab(id);
    setQuery("");
    if (focus) tabRefs.current[id]?.focus();
  };

  const onTabKey = (event) => {
    if (event.key === "ArrowRight" || event.key === "ArrowLeft") {
      event.preventDefault();
      pickTab(tab === "about" ? "staff" : "about", true);
    }
  };

  const sections = about.map((section) => filterSection(section, q)).filter(Boolean);
  const people = staff.filter((person) =>
    !q || [person.name, person.role, person.qualification, person.experience, person.about].filter(Boolean).join(" ").toLowerCase().includes(q),
  );

  return (
    <main id="main" className="cse-page">
      {/* ---- hero ---- */}
      <section className="cse-hero" aria-label={hero.title} style={{ "--img": `url("${hero.image}")` }}>
        <div className="cse-hero__photo" />
        <div className="container cse-hero__inner">
          <nav className="cse-crumbs" aria-label="Breadcrumb">
            <Link to="/">Home</Link>
            <FiChevronRight aria-hidden="true" />
            <span>Departments</span>
            <FiChevronRight aria-hidden="true" />
            <span aria-current="page">{hero.title}</span>
          </nav>
          <div className="cse-hero__text">
            <span className="cse-eyebrow">Department</span>
            <h1>{hero.title}</h1>
            <p>{hero.lead}</p>
            <ul className="cse-hero__facts">
              {hero.facts.map((fact) => (
                <li key={fact}>{fact}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <div className="container cse-wrap">
        {/* ---- department switcher ---- */}
        <nav className="cse-switch" aria-label="Departments">
          <ul className="cse-switch__list">
            {switcher.main.map((item) => (
              <li key={item.to}>
                <Link to={item.to} className={`cse-switch__link${item.to === switcher.current ? " is-current" : ""}`} aria-current={item.to === switcher.current ? "page" : undefined}>
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
          <div className="cse-more" ref={moreRef}>
            <button type="button" className="cse-switch__link cse-more__btn" aria-expanded={moreOpen} aria-haspopup="true" onClick={() => setMoreOpen((open) => !open)}>
              More +
              <FiChevronDown aria-hidden="true" />
            </button>
            {moreOpen && (
              <ul className="cse-more__menu">
                {switcher.more.map((item) => (
                  <li key={item.to}>
                    <Link to={item.to} onClick={() => setMoreOpen(false)}>{item.label}</Link>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </nav>

        {/* ---- search + tabs ---- */}
        <section className="cse-info" aria-label="Department information">
          <div className="cse-toolbar">
            <label className="cse-search">
              <FiSearch aria-hidden="true" />
              <input
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder={tab === "about" ? "Search the department information" : "Search staff by name or role"}
                aria-label={tab === "about" ? "Search the department information" : "Search staff"}
              />
              {query && (
                <button type="button" className="cse-search__clear" onClick={() => setQuery("")} aria-label="Clear search">
                  <FiX aria-hidden="true" />
                </button>
              )}
            </label>

            <div className="cse-tabs" role="tablist" aria-label="Department sections" onKeyDown={onTabKey}>
              <button
                ref={(el) => { tabRefs.current.about = el; }}
                type="button" role="tab" id="cse-tab-about" aria-selected={tab === "about"} aria-controls="cse-panel"
                tabIndex={tab === "about" ? 0 : -1} className={`cse-tab${tab === "about" ? " is-active" : ""}`} onClick={() => pickTab("about")}
              >
                <FiFileText aria-hidden="true" /> About
              </button>
              <button
                ref={(el) => { tabRefs.current.staff = el; }}
                type="button" role="tab" id="cse-tab-staff" aria-selected={tab === "staff"} aria-controls="cse-panel"
                tabIndex={tab === "staff" ? 0 : -1} className={`cse-tab${tab === "staff" ? " is-active" : ""}`} onClick={() => pickTab("staff")}
              >
                <FiUsers aria-hidden="true" /> Staff <span className="cse-tab__n">{staff.length}</span>
              </button>
            </div>
          </div>

          <div id="cse-panel" className="cse-panel" role="tabpanel" aria-labelledby={`cse-tab-${tab}`} tabIndex={0}>
            {tab === "about" ? (
              <>
                {!q && (
                  <div className="cse-collage">
                    <Photo src={collage[0].src} alt={collage[0].alt} className="cse-collage__a" />
                    <Photo src={collage[1].src} alt={collage[1].alt} className="cse-collage__b" />
                    <Photo src={collage[2].src} alt={collage[2].alt} className="cse-collage__c" />
                  </div>
                )}

                {sections.length > 0 ? (
                  <div className="cse-about">
                    {sections.map((section) => {
                      const Icon = section.icon;
                      return (
                        <article key={section.id} className={`cse-block${section.wide ? " cse-block--wide" : ""}`}>
                          <h2><span className="cse-block__icon"><Icon aria-hidden="true" /></span><Mark text={section.title} query={q} /></h2>
                          {section.paragraphs?.map((text) => <p key={text}><Mark text={text} query={q} /></p>)}
                          {section.items?.length > 0 && (
                            <ul className={`cse-items cse-items--${section.view}`}>
                              {section.items.map((item) => (
                                <li key={item}>
                                  {section.view === "list" && <FiCheckCircle aria-hidden="true" />}
                                  <span><Mark text={item} query={q} /></span>
                                </li>
                              ))}
                            </ul>
                          )}
                          {section.closing?.map((text) => <p key={text}><Mark text={text} query={q} /></p>)}
                        </article>
                      );
                    })}
                  </div>
                ) : (
                  <p className="cse-none">Nothing found for "{query}". Try another word.</p>
                )}
              </>
            ) : people.length > 0 ? (
              <ul className="cse-staff">
                {people.map((person) => (
                  <li key={person.name} className="cse-card">
                    <Avatar person={person} />
                    <div className="cse-card__body">
                      <h3><Mark text={person.name} query={q} /></h3>
                      <span className="cse-card__role"><Mark text={person.role} query={q} /></span>
                      {(person.qualification || person.experience) && (
                        <dl>
                          {person.qualification && <div><dt>Qualification</dt><dd>{person.qualification}</dd></div>}
                          {person.experience && <div><dt>Experience</dt><dd>{person.experience}</dd></div>}
                        </dl>
                      )}
                      {person.about && <p>{person.about}</p>}
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="cse-none">No staff found for "{query}". Try another name or role.</p>
            )}
          </div>
        </section>

        {/* ---- department highlights ---- */}
        <section className="cse-highlights" aria-labelledby="cse-hl-title">
          <header className="cse-head">
            <span className="cse-eyebrow cse-eyebrow--line">At a glance</span>
            <h2 id="cse-hl-title">Department <span>highlights</span></h2>
          </header>
          <ul className="cse-hl">
            {highlights.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.label} className="cse-hl__card" style={{ "--hl-img": `url("${item.image}")` }}>
                  <span className="cse-hl__icon"><Icon aria-hidden="true" /></span>
                  <div className="cse-hl__body">
                    <strong>{item.value}</strong>
                    <span className="cse-hl__label">{item.label}</span>
                    <p>{item.text}</p>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      </div>
    </main>
  );
}